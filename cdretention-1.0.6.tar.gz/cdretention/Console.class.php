<?php
namespace FreePBX\Console\Command;

use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class Cdretention extends Command {
    protected function configure() {
        $this->setName('cdretention')
             ->setDescription('Manage CDR Retention')
             ->setDefinition(array(
                 new \Symfony\Component\Console\Input\InputArgument('args', \Symfony\Component\Console\Input\InputArgument::IS_ARRAY, null, null),
             ));
    }

    protected function execute(InputInterface $input, OutputInterface $output) {
        $args = $input->getArgument('args');
        $action = isset($args[0]) ? $args[0] : '';

        $cdretention = \FreePBX::create()->Cdretention;

        switch ($action) {
            case 'purge':
                $output->writeln("Iniciando purga manual...");
                $count = $cdretention->purgeOldRecords();
                $output->writeln("Purga completada. Registros eliminados: " . $count);
                break;
            default:
                $output->writeln("Uso: fwconsole cdretention purge");
                break;
        }
        return Command::SUCCESS;
    }
}
