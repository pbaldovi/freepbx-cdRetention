<?php
namespace FreePBX\Console\Command;

use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class Cdretention extends Command {
    protected function configure() {
        $this->setName('cdretention')
            ->setDescription('CDR Retention Commands')
            ->setHelp('Run CDR Retention commands');
            
        $this->addArgument('args', \Symfony\Component\Console\Input\InputArgument::IS_ARRAY, 'Arguments');
    }

    protected function execute(InputInterface $input, OutputInterface $output) {
        $args = $input->getArgument('args');
        
        if (empty($args) || !isset($args[0])) {
            $output->writeln('<error>Usage: fwconsole cdretention purge</error>');
            return Command::FAILURE;
        }

        $action = $args[0];

        if ($action == 'purge') {
            $output->writeln('Starting CDR purge...');
            $fpbx = \FreePBX::create();
            $count = $fpbx->Cdretention->purgeOldRecords();
            $output->writeln("<info>Success: Purged $count records.</info>");
            return Command::SUCCESS;
        }

        $output->writeln("<error>Unknown command: $action</error>");
        return Command::FAILURE;
    }
}
