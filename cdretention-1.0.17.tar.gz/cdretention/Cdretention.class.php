<?php
namespace FreePBX\modules;

// Usamos FQN para evitar colisiones
use FreePBX\modules\Cdretention\Console\CdretentionConsole;

class Cdretention implements \BMO, \FreePBX\Console {
    public $message = "";
    private $FreePBX;
    private $db;

    public function __construct($FreePBX = null) {
        if ($FreePBX == null) {
            $FreePBX = \FreePBX::create();
        }
        $this->FreePBX = $FreePBX;
        $this->db = $FreePBX->Database;
    }

    public function install() {
        $this->FreePBX = \FreePBX::create();
        
        // La tabla se crea via module.xml ahora
        
        // Establecer valor por defecto
        if ($this->getConfig('purge_days') === null) {
            $this->setConfig('purge_days', 30);
        }

        // Programar tarea Cron (01:00 AM)
        $this->FreePBX->Cron->add("0 1 * * * /usr/sbin/fwconsole cdretention purge");

        // Limpiar caché de consola
        @unlink('/var/lib/asterisk/bin/console.cache');
    }

    public function uninstall() {
        $this->FreePBX = \FreePBX::create();
        $this->FreePBX->Cron->remove("/usr/sbin/fwconsole cdretention purge");
        // La tabla se maneja por BMO
        $this->FreePBX->Database->query("DROP TABLE IF EXISTS cdretention_settings");
        @unlink('/var/lib/asterisk/bin/console.cache');
    }

    public function doConfigPageInit($page) {
        $this->FreePBX = \FreePBX::create();
        
        if (isset($_POST['action'])) {
            switch ($_POST['action']) {
                case 'save':
                    $days = intval($_POST['purge_days']);
                    $this->setConfig('purge_days', $days);
                    $this->message = '<div class="alert alert-success">Configuración guardada correctamente.</div>';
                    break;
                    
                case 'purge_now':
                    $count = $this->purgeOldRecords();
                    $this->message = '<div class="alert alert-warning">Purga completada: Se eliminaron ' . $count . ' registros.</div>';
                    break;
            }
        }
    }

    public function getConfig($key) {
        $this->FreePBX = \FreePBX::create();
        $sql = "SELECT value FROM cdretention_settings WHERE `key` = :key";
        $stmt = $this->FreePBX->Database->prepare($sql);
        $stmt->execute(array(':key' => $key));
        $res = $stmt->fetch(\PDO::FETCH_ASSOC);
        return $res ? $res['value'] : null;
    }

    public function setConfig($key, $value) {
        $this->FreePBX = \FreePBX::create();
        $sql = "INSERT INTO cdretention_settings (`key`, `value`) VALUES (:key, :value) ON DUPLICATE KEY UPDATE `value` = :value";
        $stmt = $this->FreePBX->Database->prepare($sql);
        $stmt->execute(array(':key' => $key, ':value' => $value));
    }

    public function purgeOldRecords($days = null) {
        $this->FreePBX = \FreePBX::create();
        
        if ($days === null) {
            $days = $this->getConfig('purge_days');
        }
        
        if (!is_numeric($days) || $days < 1) return 0;

        $totalDeleted = 0;
        $batchSize = 5000;
        $tables = [
            ['table' => 'asteriskcdrdb.cdr', 'col' => 'calldate'],
            ['table' => 'asteriskcdrdb.cel', 'col' => 'eventtime']
        ];

        foreach ($tables as $t) {
            do {
                $sql = "DELETE FROM {$t['table']} WHERE {$t['col']} < DATE_SUB(NOW(), INTERVAL :days DAY) LIMIT :limit";
                $stmt = $this->FreePBX->Database->prepare($sql);
                $stmt->bindValue(':days', $days, \PDO::PARAM_INT);
                $stmt->bindValue(':limit', $batchSize, \PDO::PARAM_INT);
                $stmt->execute();
                
                $count = $stmt->rowCount();
                $totalDeleted += $count;
                
                if ($count > 0) {
                    usleep(50000); // 50ms pause para I/O
                }
            } while ($count > 0);
        }
        
        return $totalDeleted;
    }

    public function getConsoleCommands() {
        // Carga explícita si no se ha cargado (para seguridad, aunque debería ser automático si PSR-4 está bien)
        if (!class_exists('FreePBX\modules\Cdretention\Console\CdretentionConsole')) {
            require_once __DIR__ . '/Console/CdretentionConsole.class.php';
        }
        
        return [new CdretentionConsole($this)];
    }
}
