<?php
namespace FreePBX\modules\Cdretention\Console;

use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Input\InputArgument;

class Cdretention extends Command {
    private $module;

    public function __construct($module) {
        $this->module = $module;
        parent::__construct();
    }

    protected function configure() {
        $this->setName('cdretention')
             ->setDescription('Administrar retención de CDR')
             ->addArgument('action', InputArgument::REQUIRED, 'Acción a realizar (purge)');
    }

    protected function execute(InputInterface $input, OutputInterface $output) {
        $action = $input->getArgument('action');

        if ($action == 'purge') {
            $output->writeln("Iniciando purga de registros antiguos...");
            $count = $this->module->purgeOldRecords();
            $output->writeln("Purga finalizada. Registros eliminados: " . $count);
            return Command::SUCCESS;
        }

        $output->writeln("<error>Acción desconocida. Use: fwconsole cdretention purge</error>");
        return Command::FAILURE;
    }
}
